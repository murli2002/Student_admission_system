function getBotResponse(input) {
    //rock paper scissors
    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
    if (input == "hello") {
        return "Hello there!";
    } else if (input == "goodbye") {
        return "Talk to you later!";
    } else if (input == "Hi") {
        return "Hi there!";
    } else if (input == "end") {
        return "Talk to you later!";
    } else if (input == "when will the counselling start?") {
        return "please contact the college administration. contact number: "
    } else if (input=="what is the fee structure of category 1") {
        window.location.href = "D:/School%20Pro/feedetails.html";
    } else if (input=="what is the fee structure of category 2") {
        window.location.href = "D:/School%20Pro/feedetails.html";
    } else if (input=="what is the fee structure of category 3") {
        window.location.href = "D:/School%20Pro/feedetails.html";
    } else if (input=="what is the fee structure of category 4") {
        window.location.href = "D:/School%20Pro/feedetails.html";
    } else if (input=="what is the fee structure of category 5") {
        window.location.href = "D:/School%20Pro/feedetails.html";
    }  else if (input=="what is the fee structure of VIT?") {
        window.location.href = "D:/School%20Pro/feedetails.html";
    } else if (input=="what are the courses offered?") {
        window.location.href = "D:/School%20Pro/courses.html";
    } else if (input=="about VIT") {
        window.location.href = "D:/School%20Pro/about.html";
    } else if (input=="how to contact VIT?") {
        window.location.href = "D:/School%20Pro/contact.html";
    } else if (input=="how to register for admission?") {
        window.location.href = "D:/School%20Pro/admission.html";
    }    
}